Programmer:
Quyen Pho Tsai
Jake Wong
Benjamin Heng

Artist:
Jade McIntyre

Kitten Math
- After extracting the zip file, open kitten_math.exe to play the game. 
- To play the game on desktop, right click kitten_math.exe and select "Create shortcut", then drag the file kitten_math.exe-Shortcut to destination file.
Enjoy!

NOTE: The game will only work on Window 10 Operating system.

DISCLAIMER: WE DO NOT OWN ANY AUDIO IN THIS GAME, THE AUDIOS ARE PLACE HOLDER. ALL RIGHT RESERVED FOR MEDIATONIC, NINTENDO, AND ROBLOX CORPORATION